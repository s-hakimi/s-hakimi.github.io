__author__ = 'saeed'
import tornado
from models import *
from pycket.session import SessionManager

class show(tornado.web.RequestHandler):
    def get(self):
        show1 = project.select()
        self.render('admin.html',show1=show1)


class add(tornado.web.RequestHandler):
    def get(self):
        #session Sample
        if session.get('login')==loginuser.user : #Get user form database and check with
            self.render('new.html')
        else:
            self.redirect('/login')

    def post(self,*args):
        name = self.get_argument('name')
        maharat = self.get_argument('maharat')

        catInfo=project.create(
            name = name,
            maharat = maharat
        )
        self.redirect('/')

class edit(tornado.web.RequestHandler):
    def get(self,*args):
        id=args[0]
        catInfo=project.select().where(project.id==id).get()
        self.render('edit.html',catInfo=catInfo)

    def post(self,*args):
        id=args[0]
        catInfo=project.select().where(project.id==id).get()
        catInfo.name=self.get_argument('name')
        catInfo.maharat=self.get_argument('maharat')
        catInfo.save()
        self.redirect('/')

class delete(tornado.web.RequestHandler):
    def get(self,*args):
        id=args[0]
        catInfo=project.select().where(project.id==id).get().delete_instance()
        self.redirect('/')

class login(tornado.web.RequestHandler):
    def get(self):
        login1 = loginuser.select()
        self.render('login\index.html',login=login1)

    def post(self):
       #login1=loginuser.select().where(loginuser.id==id)#
        user1=self.get_argument('user')
        if loginuser.get(loginuser.id == 1).user==user1:
            session = SessionManager(self)
            session.set('login',loginuser.user)
            k =  session.get('login')
            self.redirect('/admin')
        else:
            self.redirect('/login')
    #print(loginuser.get(loginuser.id == 1).user)



