__author__ = 'saeed'
import tornado
from models import *
from pycket.session import SessionManager

class show(tornado.web.RequestHandler):
    def get(self):
        show1 = project.select()
        self.render('admin.html',show1=show1)


class add(tornado.web.RequestHandler):
    def get(self):
        #session Sample
        if session.get('login')==loginuser.user :
            self.render('new.html')

    def post(self,*args):
        name = self.get_argument('name')
        maharat = self.get_argument('maharat')

        catInfo=project.create(
            name = name,
            maharat = maharat
        )
        self.redirect('/')

class edit(tornado.web.RequestHandler):
    def get(self,*args):
        id=args[0]
        catInfo=project.select().where(project.id==id).get()
        self.render('edit.html',catInfo=catInfo)

    def post(self,*args):
        id=args[0]
        catInfo=project.select().where(project.id==id).get()
        catInfo.name=self.get_argument('name')
        catInfo.maharat=self.get_argument('maharat')
        catInfo.save()
        self.redirect('/')

class delete(tornado.web.RequestHandler):
    def get(self,*args):
        id=args[0]
        catInfo=project.select().where(project.id==id).get().delete_instance()
        self.redirect('/')

class login(tornado.web.RequestHandler):
    def get(self):
        login1 = loginuser.select()
        self.render('login\index.html',login=login1)

    def post(self):
        login1=loginuser.select().where(loginuser.id==id)#
        user=self.get_argument('user')
        if login1.user==user:
            session = SessionManager(self)
            session.set('login',login.user)
            k =  session.get('login')
            self.redirect('/admin')
        else:
            self.redirect('/login')




    #def post(self,*args):

        #id=args[0]
        # LogInfo = loginuser.select().where(loginuser.id==loginuser.id).get()
        # LogInfo.user=self.get_argument('user')
        # LogInfo.password=self.get_argument('pass')
        # LogInfo.save()
        # self.redirect('/admin')

# class BaseHandler(tornado.web.RequestHandler):
#
#   def get_login_url(self):
#     return u"/login"
#
#   def get_current_user(self):
#     user_json = self.get_secure_cookie("user")
#     if user_json:
#       return tornado.escape.json_decode(user_json)
#     else:
#       return None
#
#
# class LoginHandler(BaseHandler):
#
#   def get(self):
#     self.render("login\index.html", next=self.get_argument("next","/"), message=self.get_argument("error","") )
#
#   def post(self):
#     email = self.get_argument("user", "")
#     password = self.get_argument("pass", "")
#
#     user = self.application.syncdb['users'].find_one( { 'user': email } )
#
#     if user and user['password'] and bcrypt.hashpw(password, user['password']) == user['password']:
#       self.set_current_user(email)
#       self.redirect("hello")
#     else:
#       error_msg = u"?error=" + tornado.escape.url_escape("Login incorrect.")
#       self.redirect(u"/login" + error_msg)
#
#   def set_current_user(self, user):
#     print ("setting "+user)
#     if user:
#       self.set_secure_cookie("user", tornado.escape.json_encode(user))
#     else:
#       self.clear_cookie("user")
#
#
# class RegisterHandler(LoginHandler):
#
#   def get(self):
#     self.render(  "register.html", next=self.get_argument("next","/"))
#
#   def post(self):
#     email = self.get_argument("email", "")
#
#     already_taken = self.application.syncdb['users'].find_one( { 'user': email } )
#     if already_taken:
#       error_msg = u"?error=" + tornado.escape.url_escape("Login name already taken")
#       self.redirect(u"/login" + error_msg)
#
#
#     password = self.get_argument("password", "")
#     hashed_pass = bcrypt.hashpw(password, bcrypt.gensalt(8))
#
#     user = {}
#     user['user'] = email
#     user['password'] = hashed_pass
#
#     auth = self.application.syncdb['users'].save(user)
#     self.set_current_user(email)
#
#     self.redirect("hello")


#########

