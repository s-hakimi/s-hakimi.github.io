<?php
session_start();
@$username = $_POST['user'];
@$password = $_POST['pass'];
//@$check = $_POST['check'];
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Checking</title>
<style type="text/css">
body{
    font-family:Tahoma, Geneva, sans-serif;
    direction:rtl;
    font-size:12px;
}
</style>
</head>
<body>
<?php
//بررسی معتبر بودن اطلاعات ارسالی کاربر
//نام کاربری
if (!isset($username) || $username == ''){
    echo "فیلد نام کاربری نباید خالی باشد!";
    $check_error = 1;
}
//کلمه عبور
elseif (!isset($password) || $password == ''){
    echo "فیلد کلمه عبور نباید خالی باشد!";
    $check_error = 1;
}
//اطلاعات اتصال به پایگاه داده
$con = mysql_connect("localhost", "root", "")
or die(mysql_error());
//نام دیتابیس
mysql_select_db("loginuser", $con)
or die(mysql_error());
//جلوگیری از نفوذ به دیتابیس
$username = mysql_real_escape_string($username);
$password = md5($password);
if ($check_error != 1 && $check == 'sended'){
    //تطبیق اطلاعات کاربر با آنچه که در دیتابیس ذخیره شده
    $result = mysql_query ("SELECT * FROM register WHERE username = '$username' AND password = '$password'");
    // تعداد ردیف های موجود
    $count = mysql_num_rows($result);
    if($count > 0){
        // اطلاعات کاربر درست است، تنظیم مجوز های استفاده از بخش اعضاء
        $_SESSION['username'] = $_POST['user'];
        $_SESSION['password'] = $_POST['pass'];
        // اطلاعات کاربر صحیح است
        echo "شما به سایت وارد شده اید!<br />";
    }
    else{
        // اطلاعات کاربر صحیح نیست
        echo "اطلاعات وارد شده صحیح نیست!<br />";
    }
}
//پایان ارتباط با پایگاه داده
mysql_close($con);
?>
</body>
</html>