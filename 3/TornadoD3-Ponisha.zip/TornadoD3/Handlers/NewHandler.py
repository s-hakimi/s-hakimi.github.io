__author__ = 'saeed'
import tornado
from models import *
from pycket.session import SessionManager

class show(tornado.web.RequestHandler):
    def get(self):
        show1 = project.select()
        self.render('admin.html',show1=show1)
        session = SessionManager(self)
        self.session.set('loginuser',loginuser.user)
        self.session.set('loginpass',loginuser.password)
        k = self.session.get('loginuser')
        m = self.session.get('loginpass')

class add(tornado.web.RequestHandler):
    def get(self):
        self.render('new.html')
    def post(self,*args):
        name = self.get_argument('name')
        maharat = self.get_argument('maharat')

        catInfo=project.create(
            name = name,
            maharat = maharat
        )
        self.redirect('/')

class edit(tornado.web.RequestHandler):
    def get(self,*args):
        id=args[0]
        catInfo=project.select().where(project.id==id).get()
        self.render('edit.html',catInfo=catInfo)

    def post(self,*args):
        id=args[0]
        catInfo=project.select().where(project.id==id).get()
        catInfo.name=self.get_argument('name')
        catInfo.maharat=self.get_argument('maharat')
        catInfo.save()
        self.redirect('/')

class delete(tornado.web.RequestHandler):
    def get(self,*args):
        id=args[0]
        catInfo=project.select().where(project.id==id).get().delete_instance()
        self.redirect('/')

class login(tornado.web.RequestHandler):
    def get(self):
        login1 = loginuser.select()
        self.render('login\index.html',login=login1)
